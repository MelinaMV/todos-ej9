
let nombre 
nombre= prompt ('Ingrese su nombre')
console.log (nombre)

let genero = prompt ('Por favor, ingrese su genero (hombre , mujer o no binario)')

if (genero == "hombre") {
    console.log ('Bienvenido')
} 
else if (genero == "mujer") {
    console.log ('Bienvenida')
} else {
    console.log ('Bienvenidx')
}
