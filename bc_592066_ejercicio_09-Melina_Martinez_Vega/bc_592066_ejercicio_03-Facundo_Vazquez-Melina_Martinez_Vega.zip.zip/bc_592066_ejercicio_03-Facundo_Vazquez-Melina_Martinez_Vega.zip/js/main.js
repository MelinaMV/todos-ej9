let nombre

nombre = prompt ('Ingrese su nombre')

console.log(nombre)

let edad = prompt('Ingrese su edad')

if(edad < 30){
    console.log('Hola, ¿como andas?')
} else {
    console.log('Bienvenido. Buenos días')
}



